/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 87.39886125262211, "KoPercent": 12.601138747377885};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.08637998201977824, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.5325, 500, 1500, "VCard Homepage-0"], "isController": false}, {"data": [0.0, 500, 1500, "VCard Homepage"], "isController": false}, {"data": [0.0, 500, 1500, "VCard Homepage-1"], "isController": false}, {"data": [0.002631578947368421, 500, 1500, "generator-2"], "isController": false}, {"data": [0.04336468129571578, 500, 1500, "generator-1"], "isController": false}, {"data": [0.0, 500, 1500, "generator"], "isController": false}, {"data": [5.224660397074191E-4, 500, 1500, "generator-0"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 6674, 841, 12.601138747377885, 30298.28183997588, 178, 623689, 28387.5, 57727.5, 75226.25, 94089.25, 9.80879175791067, 1706.3324855946232, 1.5853607567496069], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["VCard Homepage-0", 1000, 0, 0.0, 721.363999999999, 340, 2045, 715.0, 883.9, 944.0, 1499.88, 398.72408293460927, 70.86697567783094, 48.28299441786284], "isController": false}, {"data": ["VCard Homepage", 1000, 0, 0.0, 40752.08599999998, 12825, 131366, 40932.0, 50192.0, 54825.75, 60456.19, 7.569163229005033, 1453.4620051659538, 1.8331567195246565], "isController": false}, {"data": ["VCard Homepage-1", 1000, 0, 0.0, 40030.179, 12239, 130677, 40271.0, 49414.299999999996, 54176.85, 59636.340000000004, 7.613131128570558, 1460.5517878486814, 0.921902597600341], "isController": false}, {"data": ["generator-2", 760, 202, 26.57894736842105, 44943.62368421052, 178, 97678, 38305.0, 75027.5, 83123.69999999998, 96198.42, 7.4431723584083365, 3793.2425034981684, 0.7097908015611075], "isController": false}, {"data": ["generator-1", 957, 197, 20.58516196447231, 10457.550679205857, 218, 22727, 7786.0, 21044.0, 21051.0, 21867.979999999996, 9.243072524797897, 8.855246946743677, 0.9605563711523416], "isController": false}, {"data": ["generator", 1000, 442, 44.2, 64272.53899999995, 1775, 623689, 52516.5, 89693.2, 94632.45, 612620.97, 1.4983697736862294, 582.1693692574978, 0.44525579606887705], "isController": false}, {"data": ["generator-0", 957, 0, 0.0, 12820.830721003142, 1379, 43844, 9569.0, 24985.8, 29106.99999999998, 38561.89999999997, 7.943490819748331, 1.566977681239417, 1.0394802439905044], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 2, 0.23781212841854935, 0.029967036260113874], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to testapp.cisstaging.com:80 [testapp.cisstaging.com/76.76.21.21] failed: Connection timed out: connect", 10, 1.1890606420927468, 0.1498351813005694], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: testapp.cisstaging.com:80 failed to respond", 11, 1.3079667063020215, 0.1648186994306263], "isController": false}, {"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 22, 2.615933412604043, 0.3296373988612526], "isController": false}, {"data": ["Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to testapp.cisstaging.com:443 [testapp.cisstaging.com/76.76.21.21] failed: Connection timed out: connect", 796, 94.64922711058264, 11.926880431525323], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 6674, 841, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to testapp.cisstaging.com:443 [testapp.cisstaging.com/76.76.21.21] failed: Connection timed out: connect", 796, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 22, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: testapp.cisstaging.com:80 failed to respond", 11, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to testapp.cisstaging.com:80 [testapp.cisstaging.com/76.76.21.21] failed: Connection timed out: connect", 10, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 2], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["generator-2", 760, 202, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to testapp.cisstaging.com:443 [testapp.cisstaging.com/76.76.21.21] failed: Connection timed out: connect", 201, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 1, "", "", "", "", "", ""], "isController": false}, {"data": ["generator-1", 957, 197, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to testapp.cisstaging.com:443 [testapp.cisstaging.com/76.76.21.21] failed: Connection timed out: connect", 197, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["generator", 1000, 442, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to testapp.cisstaging.com:443 [testapp.cisstaging.com/76.76.21.21] failed: Connection timed out: connect", 398, "Non HTTP response code: java.net.SocketException/Non HTTP response message: A connection attempt failed because the connected party did not properly respond after a period of time, or established connection failed because connected host has failed to respond", 22, "Non HTTP response code: org.apache.http.NoHttpResponseException/Non HTTP response message: testapp.cisstaging.com:80 failed to respond", 11, "Non HTTP response code: org.apache.http.conn.HttpHostConnectException/Non HTTP response message: Connect to testapp.cisstaging.com:80 [testapp.cisstaging.com/76.76.21.21] failed: Connection timed out: connect", 10, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 1], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
